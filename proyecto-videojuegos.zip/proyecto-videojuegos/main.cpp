#include "src/sdlapp.hpp"

int main(int argc, char *argv[]) { return SDLApp::get().on_correr(1); };