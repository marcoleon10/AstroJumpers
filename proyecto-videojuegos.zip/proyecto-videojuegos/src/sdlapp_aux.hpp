#pragma once
// #include "sdlapp.hpp"

class SDLApp_AUX {

public:
  static int get_nivel();
  static void set_nivel(int n);
};